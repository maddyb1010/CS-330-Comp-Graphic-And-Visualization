
///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads and binds the textures used in the scene.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// load textures used for the fortune-teller scene
	CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "bronze");
	CreateGLTexture("../../Utilities/textures/glass.jpg", "glass");
	CreateGLTexture("../../Utilities/textures/purplefabric.jpg", "purpleFabric");

	// bind the loaded textures to texture slots
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	// load and bind the textures used in the scene
	LoadSceneTextures();


	// Fabric material for the purple tablecloth
	// Made a little more responsive to light so the cloth
	// shows more visible sheen and highlight
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.ambientColor = glm::vec3(0.30f, 0.26f, 0.36f);
	fabricMaterial.ambientStrength = 0.20f;
	fabricMaterial.diffuseColor = glm::vec3(0.58f, 0.58f, 0.58f);
	fabricMaterial.specularColor = glm::vec3(0.18f, 0.18f, 0.18f);
	fabricMaterial.shininess = 8.0f;
	fabricMaterial.tag = "fabric";
	m_objectMaterials.push_back(fabricMaterial);


	// Bronze stand has a brighter metallic reflection.
	OBJECT_MATERIAL bronzeMaterial;
	bronzeMaterial.ambientColor = glm::vec3(0.34f, 0.27f, 0.19f);
	bronzeMaterial.ambientStrength = 0.15f;
	bronzeMaterial.diffuseColor = glm::vec3(0.44f, 0.40f, 0.34f);
	bronzeMaterial.specularColor = glm::vec3(0.35f, 0.31f, 0.25f);
	bronzeMaterial.shininess = 12.0f;
	bronzeMaterial.tag = "bronzeMetal";
	m_objectMaterials.push_back(bronzeMaterial);

	// Crystal ball keeps its icy texture with reflective highlights.
	OBJECT_MATERIAL crystalMaterial;
	crystalMaterial.ambientColor = glm::vec3(0.29f, 0.32f, 0.36f);
	crystalMaterial.ambientStrength = 0.14f;
	crystalMaterial.diffuseColor = glm::vec3(0.45f, 0.47f, 0.49f);
	crystalMaterial.specularColor = glm::vec3(0.36f, 0.38f, 0.42f);
	crystalMaterial.shininess = 16.0f;
	crystalMaterial.tag = "crystal";
	m_objectMaterials.push_back(crystalMaterial);


	// Wax material for the white pillar candles
	OBJECT_MATERIAL waxMaterial;
	waxMaterial.ambientColor = glm::vec3(0.30f, 0.29f, 0.25f);
	waxMaterial.ambientStrength = 0.28f;
	waxMaterial.diffuseColor = glm::vec3(0.60f, 0.58f, 0.52f);
	waxMaterial.specularColor = glm::vec3(0.12f, 0.11f, 0.10f);
	waxMaterial.shininess = 3.0f;
	waxMaterial.tag = "wax";
	m_objectMaterials.push_back(waxMaterial);

	// Dark metallic material for the candleholders
	OBJECT_MATERIAL ironMaterial;
	ironMaterial.ambientColor = glm::vec3(0.19f, 0.18f, 0.18f);
	ironMaterial.ambientStrength = 0.20f;
	ironMaterial.diffuseColor = glm::vec3(0.45f, 0.44f, 0.43f);
	ironMaterial.specularColor = glm::vec3(0.33f, 0.32f, 0.30f);
	ironMaterial.shininess = 18.0f;
	ironMaterial.tag = "iron";
	m_objectMaterials.push_back(ironMaterial);

	// Matte paper material for the tarot cards
	OBJECT_MATERIAL paperMaterial;
	paperMaterial.ambientColor = glm::vec3(0.33f, 0.33f, 0.34f);
	paperMaterial.ambientStrength = 0.25f;
	paperMaterial.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	paperMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	paperMaterial.shininess = 2.0f;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);

	// Warm yellow-orange material for candle flames
	OBJECT_MATERIAL flameMaterial;
	flameMaterial.ambientColor = glm::vec3(0.60f, 0.38f, 0.15f);
	flameMaterial.ambientStrength = 0.60f;
	flameMaterial.diffuseColor = glm::vec3(0.65f, 0.45f, 0.20f);
	flameMaterial.specularColor = glm::vec3(0.0f);
	flameMaterial.shininess = 1.0f;
	flameMaterial.tag = "flame";
	m_objectMaterials.push_back(flameMaterial);

	// Configure two lights for the scene; the original shader is unchanged.
	// Main neutral light above and slightly in front of the scene
	m_pShaderManager->setVec3Value("lightSources[0].position", -2.0f, 9.0f, 4.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.030f, 0.030f, 0.030f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.55f, 0.55f, 0.55f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.35f, 0.35f, 0.35f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 28.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.12f);

	// Secondary accent light near the ball to fake a subtle glow
	// onto the nearby fabric
	m_pShaderManager->setVec3Value("lightSources[1].position", 1.5f, 2.8f, 1.8f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.030f, 0.018f, 0.055f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.45f, 0.35f, 0.60f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.25f, 0.20f, 0.35f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 20.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.10f);

	// Disable unused light positions to avoid unwanted diffuse/specular light.
	// The supplied shader still adds material ambient lighting per slot.
	for (int i = 2; i < 4; i++)
	{
		std::string light = "lightSources[" + std::to_string(i) + "].";
		m_pShaderManager->setVec3Value(light + "position", 0.0f, -100.0f, 0.0f);
		m_pShaderManager->setVec3Value(light + "ambientColor", 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(light + "diffuseColor", 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setVec3Value(light + "specularColor", 0.0f, 0.0f, 0.0f);
		m_pShaderManager->setFloatValue(light + "focalStrength", 24.0f);
		m_pShaderManager->setFloatValue(light + "specularIntensity", 0.0f);
	}

	// Enable Phong lighting while keeping the existing textures.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Load the basic meshes needed for the crystal ball
	// and its stand.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();

}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


	/****************************************************************/
	// TABLE SURFACE

	scaleXYZ = glm::vec3(12.0f, 1.0f, 8.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply and tile the purple floral fabric across the table surface
	SetShaderMaterial("fabric");
	SetShaderTexture("purpleFabric");
	SetTextureUVScale(4.0f, 4.0f);

	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/
	// BOTTOM CYLINDER - wider lower base of the stand

	scaleXYZ = glm::vec3(1.90f, 0.70f, 1.90f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply bronze texture to the lower base
	SetShaderMaterial("bronzeMetal");
	SetShaderTexture("bronze");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	// UPPER TAPERED CYLINDER - taller so the visible taper is subtle
	// Much of this piece is hidden inside the lower base and the ball,
	// leaving only a slightly tapered section visible.

	scaleXYZ = glm::vec3(1.90f, 3.20f, 1.90f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.15f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply metallic texture to the upper stand
	SetShaderMaterial("bronzeMetal");
	SetShaderTexture("bronze");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawTaperedCylinderMesh();


	/****************************************************************/
	// CRYSTAL BALL

	scaleXYZ = glm::vec3(1.85f, 1.85f, 1.85f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 3.10f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply glass texture to the crystal ball
	SetShaderMaterial("crystal");
	SetShaderTexture("glass");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawSphereMesh();

	/********************************************************/
	// TWO CANDLES - one on each side of the crystal ball
	DrawCandle(-4.3f, -1.0f, true);
	DrawCandle(4.3f, -1.0f, false);

	/********************************************************/
	// Four tarot cards in the back row
	const float backRowX[] = {
		-2.55f, -0.85f, 0.85f, 2.55f
	};

	for (int i = 0; i < 4; ++i)
	{
		DrawTarotCard(backRowX[i], 3.2f, 0.0f);
	}

	// Three tarot cards in the front row
	const float frontRowX[] = {
		-1.7f, 0.0f, 1.7f
	};

	for (int i = 0; i < 3; ++i)
	{
		DrawTarotCard(frontRowX[i], 4.65f, 0.0f);
	}

	/********************************************************/
	// STACK OF TAROT CARDS - left side of table
	DrawColoredBox(
		glm::vec3(1.30f, 0.28f, 0.85f),
		glm::vec3(-4.55f, 0.15f, 3.15f),
		glm::vec3(0.85f, 0.86f, 0.80f),
		"paper",
		-9.0f
	);

	// Blue top card on the stack
	DrawColoredBox(
		glm::vec3(1.22f, 0.025f, 0.78f),
		glm::vec3(-4.55f, 0.305f, 3.15f),
		glm::vec3(0.17f, 0.33f, 0.57f),
		"paper",
		-9.0f
	);

	// Gold decorative border on the top stack card
	DrawColoredBox(
		glm::vec3(0.88f, 0.006f, 0.56f),
		glm::vec3(-4.55f, 0.322f, 3.15f),
		glm::vec3(0.85f, 0.72f, 0.42f),
		"paper",
		-9.0f
	);

	// Dark blue center area inside the border
	DrawColoredBox(
		glm::vec3(0.80f, 0.006f, 0.48f),
		glm::vec3(-4.55f, 0.328f, 3.15f),
		glm::vec3(0.12f, 0.27f, 0.50f),
		"paper",
		-9.0f
	);

	// Gold diamond in the center of the top stack card
	DrawColoredBox(
		glm::vec3(0.18f, 0.007f, 0.18f),
		glm::vec3(-4.55f, 0.335f, 3.15f),
		glm::vec3(0.85f, 0.72f, 0.42f),
		"paper",
		36.0f
	);

	// Small blue diamond inside the gold one
	DrawColoredBox(
		glm::vec3(0.11f, 0.007f, 0.11f),
		glm::vec3(-4.55f, 0.342f, 3.15f),
		glm::vec3(0.12f, 0.27f, 0.50f),
		"paper",
		36.0f
	);
}

/***********************************************************
 * DrawColoredBox()
 * Draws a box with a specified size, position, and color.
 ***********************************************************/
void SceneManager::DrawColoredBox(
	glm::vec3 scale,
	glm::vec3 position,
	glm::vec3 color,
	std::string materialTag,
	float yRotation)
{
	SetTransformations(
		scale, 0.0f, yRotation, 0.0f, position);

	SetShaderMaterial(materialTag);
	SetShaderColor(color.r, color.g, color.b, 1.0f);

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 * DrawColoredCylinder()
 * Draws a cylinder with a specified size and material.
 ***********************************************************/
void SceneManager::DrawColoredCylinder(
	glm::vec3 scale,
	glm::vec3 position,
	glm::vec3 color,
	std::string materialTag)
{
	SetTransformations(
		scale, 0.0f, 0.0f, 0.0f, position);

	SetShaderMaterial(materialTag);
	SetShaderColor(color.r, color.g, color.b, 1.0f);

	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 * DrawColoredCone()
 * Draws a cone with a specified size and color.
 ***********************************************************/
void SceneManager::DrawColoredCone(
	glm::vec3 scale,
	glm::vec3 position,
	glm::vec3 color,
	std::string materialTag)
{
	SetTransformations(
		scale, 0.0f, 0.0f, 0.0f, position);

	SetShaderMaterial(materialTag);
	SetShaderColor(color.r, color.g, color.b, 1.0f);

	m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 * DrawCandle()
 * Combines cylinders and a cone to create a candle
 * with a metallic holder and a small flame.
 ***********************************************************/
void SceneManager::DrawCandle(
	float x, float z, bool tallHolder)
{
	// Different holder colors for each candle
	const glm::vec3 holderColor = tallHolder ?
		glm::vec3(0.21f, 0.19f, 0.20f) :
		glm::vec3(0.39f, 0.34f, 0.27f);

	const glm::vec3 waxColor(
		0.95f, 0.91f, 0.78f);

	const float stemHeight =
		tallHolder ? 2.70f : 2.35f;

	const float trayHeight = 0.14f + stemHeight;

	const float waxHeight =
		tallHolder ? 1.75f : 1.80f;

	// Wide base of the candleholder
	DrawColoredCylinder(
		glm::vec3(0.72f, 0.14f, 0.72f),
		glm::vec3(x, 0.02f, z),
		holderColor, "iron");

	// Thin vertical stem
	DrawColoredCylinder(
		glm::vec3(0.115f, stemHeight, 0.115f),
		glm::vec3(x, 0.16f, z),
		holderColor, "iron");

	// Small tray supporting the candle
	DrawColoredCylinder(
		glm::vec3(0.80f, 0.16f, 0.80f),
		glm::vec3(x, trayHeight, z),
		holderColor, "iron");

	// White candle sitting on the holder
	const float waxBottom = trayHeight + 0.16f;

	DrawColoredCylinder(
		glm::vec3(0.64f, waxHeight, 0.64f),
		glm::vec3(x, waxBottom, z),
		waxColor, "wax");

	// Small cone representing the candle flame
	const float waxTop = waxBottom + waxHeight;

	DrawColoredCone(
		glm::vec3(0.17f, 0.36f, 0.17f),
		glm::vec3(x, waxTop - 0.02f, z),
		glm::vec3(1.0f, 0.63f, 0.16f),
		"flame");
}

/***********************************************************
 * DrawTarotCard()
 * Combines three thin boxes to create a tarot card.
 * Reused for each card in the spread.
 ***********************************************************/
void SceneManager::DrawTarotCard(
	float x, float z, float yRotation)
{
	// Cream-colored card edges
	DrawColoredBox(
		glm::vec3(0.92f, 0.06f, 1.20f),
		glm::vec3(x, 0.055f, z),
		glm::vec3(0.90f, 0.85f, 0.71f),
		"paper", yRotation);

	// Dark blue card backing
	DrawColoredBox(
		glm::vec3(0.86f, 0.018f, 1.14f),
		glm::vec3(x, 0.095f, z),
		glm::vec3(0.13f, 0.30f, 0.62f),
		"paper", yRotation);

	// Lighter blue design in the center
	DrawColoredBox(
		glm::vec3(0.70f, 0.010f, 0.98f),
		glm::vec3(x, 0.110f, z),
		glm::vec3(0.31f, 0.51f, 0.77f),
		"paper", yRotation);

	// Gold decorative border
	DrawColoredBox(
		glm::vec3(0.60f, 0.006f, 0.86f),
		glm::vec3(x, 0.120f, z),
		glm::vec3(0.85f, 0.72f, 0.42f),
		"paper", yRotation);

	// Dark blue area inside the gold border
	DrawColoredBox(
		glm::vec3(0.54f, 0.006f, 0.80f),
		glm::vec3(x, 0.126f, z),
		glm::vec3(0.12f, 0.27f, 0.50f),
		"paper", yRotation);

	// Gold diamond in the center
	DrawColoredBox(
		glm::vec3(0.24f, 0.007f, 0.24f),
		glm::vec3(x, 0.133f, z),
		glm::vec3(0.85f, 0.72f, 0.42f),
		"paper", yRotation + 45.0f);

	// Smaller blue diamond inside the gold one
	DrawColoredBox(
		glm::vec3(0.16f, 0.007f, 0.16f),
		glm::vec3(x, 0.140f, z),
		glm::vec3(0.12f, 0.27f, 0.50f),
		"paper", yRotation + 45.0f);

	// Small gold center detail
	DrawColoredBox(
		glm::vec3(0.055f, 0.007f, 0.055f),
		glm::vec3(x, 0.147f, z),
		glm::vec3(0.90f, 0.78f, 0.48f),
		"paper", yRotation);

}